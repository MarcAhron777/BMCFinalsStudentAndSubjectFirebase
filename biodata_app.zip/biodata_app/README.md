# Biodata App

3-step biodata form (Details -> Subjects -> Review) that saves to Cloud Firestore.

## Setup (Windows, VS Code terminal inside this folder)

1. flutter create .
2. COPY lib/main.dart from the original download over lib/main.dart again
   (flutter create may replace it with the default counter app).
3. flutter pub add firebase_core cloud_firestore
4. flutter pub get
5. dart pub global run flutterfire_cli:flutterfire configure --project=YOUR-PROJECT-ID
6. flutter run -d chrome

Firestore: Build > Firestore Database > Create database (asia-southeast1, test mode).

Data is saved in collection `students`:
  name, section, course, subjects[{subject, startTime, endTime}], createdAt
